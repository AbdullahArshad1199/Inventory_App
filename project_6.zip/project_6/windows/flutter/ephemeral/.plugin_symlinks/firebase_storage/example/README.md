# firebase_storage_example

Demonstrates how to use the firebase_storage plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
