import 'package:flutter/material.dart';

class EditProductScreen extends StatefulWidget {
  final String productId;
  final String productName;
  final String company;
  final double purchasePrice;
  final double salePrice;
  final int stockQuantity;

  EditProductScreen({
    required this.productId,
    required this.productName,
    required this.company,
    required this.purchasePrice,
    required this.salePrice,
    required this.stockQuantity,
  });

  @override
  _EditProductScreenState createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<EditProductScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _companyController;
  late TextEditingController _purchasePriceController;
  late TextEditingController _salePriceController;
  late TextEditingController _stockController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.productName);
    _companyController = TextEditingController(text: widget.company);
    _purchasePriceController = TextEditingController(text: widget.purchasePrice.toString());
    _salePriceController = TextEditingController(text: widget.salePrice.toString());
    _stockController = TextEditingController(text: widget.stockQuantity.toString());
  }

  void _updateProduct() {
    if (_formKey.currentState!.validate()) {
      // Logic to update product in database
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Product Updated Successfully!')),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Edit Product')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                _buildTextField(_nameController, 'Product Name', Icons.shopping_bag),
                _buildTextField(_companyController, 'Company Name', Icons.business),
                _buildTextField(_purchasePriceController, 'Purchase Price', Icons.money, isNumeric: true),
                _buildTextField(_salePriceController, 'Sale Price', Icons.attach_money, isNumeric: true),
                _buildTextField(_stockController, 'Stock Quantity', Icons.store, isNumeric: true),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _updateProduct,
                  child: Text('Update Product', style: TextStyle(fontSize: 18)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon, {bool isNumeric = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: controller,
        keyboardType: isNumeric ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        ),
        validator: (value) => value!.isEmpty ? 'Please enter $label' : null,
      ),
    );
  }
}
