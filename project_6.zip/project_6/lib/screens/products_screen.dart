import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import '../models/product_model.dart';
import '../services/database_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Products App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ProductsScreen(),
    );
  }
}

class ProductsScreen extends StatefulWidget {
  @override
  _ProductsScreenState createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  List<Product> _products = [];
  List<Product> _filteredProducts = [];

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  // Load products from Firebase
  void _loadProducts() async {
    try {
      List<Product> products = await DatabaseService().fetchProducts();
      setState(() {
        _products = products;
        _filteredProducts = List.from(_products);
      });
    } catch (error) {
      print('Error fetching products: $error');
    }
  }

  // Add Product
  void _addProduct(Product product) async {
    try {
      await DatabaseService().addProduct(product);
      setState(() {
        _products.add(product);
        _filteredProducts = List.from(_products);
      });
    } catch (error) {
      print('Error adding product: $error');
    }
  }

  // Search Product
  void _searchProduct(String query) {
    setState(() {
      _filteredProducts = _products
          .where((product) => product.name.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  // Edit Product
  void _editProduct(Product product) async {
    // Show dialog or navigate to edit screen (this is a placeholder)
    print('Edit Product: ${product.name}');
  }

  // Delete Product
  void _deleteProduct(String productId, int index) async {
    try {
      await DatabaseService().deleteProduct(productId);
      setState(() {
        _products.removeAt(index);
        _filteredProducts = List.from(_products);
      });
    } catch (error) {
      print('Error deleting product: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Products'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              // Add Product
              // Open a dialog or a new screen to add a product
            },
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              onChanged: _searchProduct,
              decoration: InputDecoration(
                labelText: 'Search Product',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: _filteredProducts.isEmpty
                  ? Center(child: Text("No products found!", style: TextStyle(fontSize: 16)))
                  : ListView.builder(
                itemCount: _filteredProducts.length,
                itemBuilder: (context, index) {
                  final product = _filteredProducts[index];
                  return Card(
                    elevation: 3,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    child: ListTile(
                      leading: Icon(Icons.inventory, color: Colors.blue),
                      title: Text(product.name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      subtitle: Text(
                        'Company: ${product.companyName} \nPrice: \$${product.salePrice} \nStock: ${product.stockQuantity}',
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit, color: Colors.green),
                            onPressed: () => _editProduct(product),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _deleteProduct(product.id, index),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
