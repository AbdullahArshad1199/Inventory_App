import 'package:flutter/material.dart';

class InvoiceScreen extends StatelessWidget {
  final Map<String, dynamic> invoiceData;

  InvoiceScreen({required this.invoiceData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Invoice')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          elevation: 4,
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Text(
                    'INVOICE',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(height: 10),
                Text('Invoice No: #${invoiceData['invoiceNumber']}', style: TextStyle(fontSize: 16)),
                Text('Date: ${invoiceData['date']}', style: TextStyle(fontSize: 16)),
                Divider(),
                Text('Customer: ${invoiceData['customer']}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                _buildInvoiceItem('Product:', invoiceData['product']),
                _buildInvoiceItem('Quantity:', '${invoiceData['quantity']}'),
                _buildInvoiceItem('Price:', '\$${invoiceData['price']}'),
                _buildInvoiceItem('Total:', '\$${invoiceData['total']}', isBold: true),
                SizedBox(height: 20),
                Center(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      // TODO: Implement print/download functionality
                    },
                    icon: Icon(Icons.print),
                    label: Text('Print/Download Invoice'),
                    style: ElevatedButton.styleFrom(padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInvoiceItem(String label, String value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
          Text(value, style: TextStyle(fontSize: 16, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
        ],
      ),
    );
  }
}
