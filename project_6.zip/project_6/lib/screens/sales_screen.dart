import 'package:flutter/material.dart';
import '../models/sales_model.dart';
import '../services/database_service.dart';

class SalesScreen extends StatefulWidget {
  @override
  _SalesScreenState createState() => _SalesScreenState();
}

class _SalesScreenState extends State<SalesScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Sale> sales = [];
  List<Sale> filteredSales = [];

  @override
  void initState() {
    super.initState();
    _loadSales();
  }

  // Fetch sales from Firestore
  void _loadSales() async {
    try {
      List<Sale> fetchedSales = await DatabaseService().fetchSales();
      setState(() {
        sales = fetchedSales;
        filteredSales = List.from(sales);
      });
    } catch (error) {
      print('Error fetching sales: $error');
    }
  }

  // Filter sales based on product or customer
  void _filterSales(String query) {
    setState(() {
      filteredSales = sales.where((sale) {
        return sale.products.any((product) => product['product'].toLowerCase().contains(query.toLowerCase())) ||
            sale.customerId.toLowerCase().contains(query.toLowerCase());
      }).toList();
    });
  }

  // Add Sale
  void _addSale(Sale sale) async {
    try {
      await DatabaseService().addSale(sale);
      setState(() {
        sales.add(sale);
        filteredSales = List.from(sales);
      });
    } catch (error) {
      print('Error adding sale: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sales Transactions')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search by Product or Customer',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onChanged: _filterSales,
            ),
            SizedBox(height: 10),
            Expanded(
              child: filteredSales.isEmpty
                  ? Center(child: Text("No sales found!", style: TextStyle(fontSize: 16)))
                  : ListView.builder(
                itemCount: filteredSales.length,
                itemBuilder: (context, index) {
                  final sale = filteredSales[index];
                  return Card(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    elevation: 4,
                    margin: EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      leading: Icon(Icons.shopping_cart, color: Colors.blue),
                      title: Text(sale.products.first['product'], style: TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(
                        'Customer: ${sale.customerId}\nQuantity: ${sale.products.length}\nDate: ${sale.saleDate.toLocal().toString().split(' ')[0]}',
                      ),
                      trailing: Text('\$${sale.totalAmount}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green)),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                // Navigate to Add Sale Screen (implement add sale screen here)
              },
              child: Text('Add New Sale', style: TextStyle(fontSize: 18)),
            ),
          ],
        ),
      ),
    );
  }
}
