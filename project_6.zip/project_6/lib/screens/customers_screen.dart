import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/database_service.dart';  // Assuming you have created the service for DB operations
import '../models/customer_model.dart';

class CustomersScreen extends StatefulWidget {
  @override
  _CustomersScreenState createState() => _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  final DatabaseService _databaseService = DatabaseService();
  List<Customer> _customers = [];
  List<Customer> _filteredCustomers = [];

  @override
  void initState() {
    super.initState();
    _loadCustomers();
  }

  Future<void> _loadCustomers() async {
    List<Customer> customers = await _databaseService.fetchCustomers();
    setState(() {
      _customers = customers;
      _filteredCustomers = List.from(_customers);
    });
  }

  void _searchCustomer(String query) {
    setState(() {
      _filteredCustomers = _customers
          .where((customer) =>
      customer.name.toLowerCase().contains(query.toLowerCase()) ||
          customer.id.toLowerCase().contains(query.toLowerCase()) ||
          customer.contact.contains(query))
          .toList();
    });
  }

  void _deleteCustomer(String customerId, int index) {
    _databaseService.deleteCustomer(customerId);
    setState(() {
      _customers.removeAt(index);
      _filteredCustomers = List.from(_customers);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Customer deleted!')),
    );
  }

  void _addCustomer() {
    // Implement Add customer functionality (Navigate to Add Customer screen)
  }

  void _editCustomer(int index) {
    // Implement Edit customer functionality (Navigate to Edit Customer screen)
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Customers')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              onChanged: _searchCustomer,
              decoration: InputDecoration(
                labelText: 'Search Customer',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            SizedBox(height: 16),
            Expanded(
              child: _filteredCustomers.isEmpty
                  ? Center(child: Text('No customers found!'))
                  : ListView.builder(
                itemCount: _filteredCustomers.length,
                itemBuilder: (context, index) {
                  return Card(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    elevation: 4,
                    child: ListTile(
                      leading: Icon(Icons.person, color: Colors.blue, size: 40),
                      title: Text(_filteredCustomers[index].name,
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      subtitle: Text(
                          'ID: ${_filteredCustomers[index].id}\nPhone: ${_filteredCustomers[index].contact}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit, color: Colors.green),
                            onPressed: () => _editCustomer(index),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _deleteCustomer(_filteredCustomers[index].id, index),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addCustomer,
        child: Icon(Icons.add),
      ),
    );
  }
}
