import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  // Define the dashboard items at the class level
  final List<Map<String, dynamic>> dashboardItems = [
    {'icon': Icons.inventory, 'title': 'Products', 'color': Colors.blue, 'route': '/products'},
    {'icon': Icons.people, 'title': 'Customers', 'color': Colors.green, 'route': '/customers'},
    {'icon': Icons.shopping_cart, 'title': 'Sales', 'color': Colors.orange, 'route': '/sales'},
    {'icon': Icons.qr_code_scanner, 'title': 'Scan Barcode', 'color': Colors.purple, 'route': '/barcode'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          Stack(
            children: [
              IconButton(
                icon: Icon(Icons.notifications_active, color: Colors.red),
                onPressed: () {
                  print('Notification clicked!');
                },
              ),
              Positioned(
                right: 8,
                top: 8,
                child: Container(
                  padding: EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  constraints: BoxConstraints(
                    minWidth: 16,
                    minHeight: 16,
                  ),
                  child: Text(
                    '3', // Dynamic notification count
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Dashboard',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: dashboardItems.length,
                itemBuilder: (context, index) {
                  return _buildDashboardItem(
                    context,
                    dashboardItems[index]['icon'],
                    dashboardItems[index]['title'],
                    dashboardItems[index]['color'],
                    dashboardItems[index]['route'],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardItem(BuildContext context, IconData icon, String title, Color color, String route) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, route);
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        elevation: 4,
        color: color.withOpacity(0.2),
        margin: EdgeInsets.symmetric(vertical: 8),
        child: ListTile(
          leading: Icon(icon, size: 40, color: color),
          title: Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          trailing: Icon(Icons.arrow_forward_ios, color: color),
        ),
      ),
    );
  }
}
