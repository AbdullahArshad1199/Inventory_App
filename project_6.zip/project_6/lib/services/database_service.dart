import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product_model.dart';
import '../models/customer_model.dart';
import '../models/sales_model.dart';

class DatabaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Add Product
  Future<void> addProduct(Product product) async {
    await _db.collection('products').doc(product.id).set(product.toJson());
  }

  // Fetch Products
  Future<List<Product>> fetchProducts() async {
    var snapshot = await _db.collection('products').get();
    return snapshot.docs.map((doc) => Product.fromJson(doc.data())).toList();
  }

  // Update Product
  Future<void> updateProduct(Product product) async {
    await _db.collection('products').doc(product.id).update(product.toJson());
  }

  // Delete Product
  Future<void> deleteProduct(String productId) async {
    await _db.collection('products').doc(productId).delete();
  }

  // Add Customer
  Future<void> addCustomer(Customer customer) async {
    await _db.collection('customers').doc(customer.id).set(customer.toJson());
  }

  // Fetch Customers
  Future<List<Customer>> fetchCustomers() async {
    var snapshot = await _db.collection('customers').get();
    return snapshot.docs.map((doc) => Customer.fromJson(doc.data())).toList();
  }
  // Delete Customer
  Future<void> deleteCustomer(String customerId) async {
    await _db.collection('customers').doc(customerId).delete();
  }
  // Add Sale
  Future<void> addSale(Sale sale) async {
    await _db.collection('sales').doc(sale.saleId).set(sale.toJson());
  }

  // Fetch Sales
  Future<List<Sale>> fetchSales() async {
    var snapshot = await _db.collection('sales').get();
    return snapshot.docs.map((doc) => Sale.fromJson(doc.data())).toList();
  }
}
