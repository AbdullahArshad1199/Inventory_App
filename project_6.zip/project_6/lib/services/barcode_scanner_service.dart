import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:flutter/material.dart';

class BarcodeScannerService {
  final MobileScannerController scannerController = MobileScannerController();

  Future<String?> scanBarcode(BuildContext context) async {
    String? scannedCode;

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Scan Barcode"),
        content: SizedBox(
          height: 250,
          width: 250,
          child: MobileScanner(
            controller: scannerController,
            onDetect: (barcodeCapture) {
              final barcode = barcodeCapture.barcodes.first;
              if (barcode.rawValue != null) {
                scannedCode = barcode.rawValue;
                Navigator.pop(context);
              }
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
        ],
      ),
    );
    return scannedCode;
  }
}
