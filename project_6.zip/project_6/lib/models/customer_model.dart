class Customer {
  String id;
  String name;
  String contact;
  String email;
  List<Map<String, dynamic>> purchaseHistory;

  Customer({
    required this.id,
    required this.name,
    required this.contact,
    required this.email,
    required this.purchaseHistory,
  });

  // Convert Customer object to JSON for database storage
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'contact': contact,
      'email': email,
      'purchaseHistory': purchaseHistory,
    };
  }

  // Create a Customer object from JSON (fetching from database)
  factory Customer.fromJson(Map<String, dynamic> json) {
    return Customer(
      id: json['id'],
      name: json['name'],
      contact: json['contact'],
      email: json['email'],
      purchaseHistory: List<Map<String, dynamic>>.from(json['purchaseHistory'] ?? []),
    );
  }
}
