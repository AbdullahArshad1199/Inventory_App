class Sale {
  String saleId;
  String customerId;
  List<Map<String, dynamic>> products;
  double totalAmount;
  DateTime saleDate;

  Sale({
    required this.saleId,
    required this.customerId,
    required this.products,
    required this.totalAmount,
    required this.saleDate,
  });

  // Convert Sale object to JSON for database storage
  Map<String, dynamic> toJson() {
    return {
      'saleId': saleId,
      'customerId': customerId,
      'products': products,
      'totalAmount': totalAmount,
      'saleDate': saleDate.toIso8601String(),
    };
  }

  // Create a Sale object from JSON (fetching from database)
  factory Sale.fromJson(Map<String, dynamic> json) {
    return Sale(
      saleId: json['saleId'],
      customerId: json['customerId'],
      products: List<Map<String, dynamic>>.from(json['products'] ?? []),
      totalAmount: json['totalAmount'].toDouble(),
      saleDate: DateTime.parse(json['saleDate']),
    );
  }
}
