class Product {
  String id;
  String name;
  String serialNumber;
  String companyName;
  double purchasePrice;
  double salePrice;
  int stockQuantity;
  int totalSales;

  Product({
    required this.id,
    required this.name,
    required this.serialNumber,
    required this.companyName,
    required this.purchasePrice,
    required this.salePrice,
    required this.stockQuantity,
    required this.totalSales,
  });

  // Convert Product object to JSON for database storage
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'serialNumber': serialNumber,
      'companyName': companyName,
      'purchasePrice': purchasePrice,
      'salePrice': salePrice,
      'stockQuantity': stockQuantity,
      'totalSales': totalSales,
    };
  }

  // Create a Product object from JSON (fetching from database)
  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'],
      name: json['name'],
      serialNumber: json['serialNumber'],
      companyName: json['companyName'],
      purchasePrice: json['purchasePrice'].toDouble(),
      salePrice: json['salePrice'].toDouble(),
      stockQuantity: json['stockQuantity'],
      totalSales: json['totalSales'],
    );
  }
}
